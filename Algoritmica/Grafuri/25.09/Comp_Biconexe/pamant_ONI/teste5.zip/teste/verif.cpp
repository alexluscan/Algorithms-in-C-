#include <cstdio>
#include <vector>
#include <cstdlib>
using namespace std;

#define FILE_OK  "pamant.ok"
#define FILE_OUT "pamant.out"

void error(int points, char *msg) {
	printf("%d %s", points, msg);
	exit(0);
}

int main(void) {
	int conOK, conOUT, pointsOK, pointsOUT;
	vector <int> vconOK, vpointsOK, vconOUT, vpointsOUT;
	
	FILE *fi = fopen(FILE_OK, "r");
	if (!fi)	error(0, "Fisierul de verificare lipseste!");
	fscanf(fi, "%d", &conOK);
	for (int i = 0; i < conOK; ++ i) {
		int number;
		fscanf(fi, "%d", &number);
		vconOK.push_back(number);
	}
	fscanf(fi, "%d", &pointsOK);
	for (int i = 0; i < pointsOK; ++ i) {
		int number;
		fscanf(fi, "%d", &number);
		vpointsOK.push_back(number);
	}
	fclose(fi);
		
	int score = 0;   char *msg;
	fi = fopen(FILE_OUT, "r");
	if (!fi)	error(0, "Fisierul de iesire lipseste!");
	if (fscanf(fi, "%d", &conOUT) != 1)
		error(0, "Raspuns incorect");
	for (int i = 0; i < conOUT; ++ i) {
		int number;
		if (fscanf(fi, "%d", &number) != 1)
			error(0, "Raspuns incorect");
		vconOUT.push_back(number);
	}
	score = 4;  msg = "Raspuns partial corect";
	if (conOK == conOUT) {
		for (int i = 0; i < conOK; ++ i) if (vconOK[i] != vconOUT[i]) {
			score = 0;
			msg = "Raspuns incorect";
		}
	} else {
		score = 0;
		msg = "Raspuns incorect";
	}
	
	if (fscanf(fi, "%d", &pointsOUT) != 1)
		error(score, msg);
	for (int i = 0; i < pointsOK; ++ i) {
		int number;
		if (fscanf(fi, "%d", &number) != 1)
			error(score, msg);
		vpointsOUT.push_back(number);
	}
	int score2 = 6;
	if (pointsOK == pointsOUT) {
		for (int i = 0; i < pointsOK; ++ i) if (vpointsOK[i] != vpointsOUT[i])
			score2 = 0;
	} else
		score2 = 0;
	
	score += score2;
	if (score == 0)
		error(0, "Raspuns incorect");
	if (score < 10)
		error(score + score2, "Raspuns partial corect");
	error(10, "Raspuns corect");
	
	return 0;
}

